
# Slots server

[![GitHub release][1]][2]
[![Hits-of-Code][3]][4]

[1]: https://img.shields.io/github/v/release/slotopol/server.svg
[2]: https://github.com/slotopol/server/releases/latest
[3]: https://hitsofcode.com/github/slotopol/server?branch=main
[4]: https://hitsofcode.com/github/slotopol/server/view?branch=main

![slotopol-server](docs/logo.webp)

Slots games server. Releases functionality a wide variety of games from different providers like Novomatic, NetEnt, and CT Interactive. Has built-in reels scanner and the sets of reels on different RTP for each game.

Server provides HTTP-based API for popular slots and have well-optimized performance for thousands requests per second. Can be deployed on dedicated server or as portable application for Linux or Windows.

```text
total: 344 games, 175 algorithms, 11 providers
AGT: 65 games
Aristocrat: 6 games
BetSoft: 3 games
CT Interactive: 140 games
IGT: 5 games
Megajack: 4 games
NetEnt: 22 games
Novomatic: 86 games
Play'n GO: 3 games
Playtech: 8 games
Slotopol: 2 games
```

*Last added games*:

* '[Treasure Chase](https://www.livebet.com/casino/slots/ct-interactive/treasure-chase)' CT Interactive 5x3 cascade videoslot
* '[Win Feast](https://www.livebet.com/casino/slots/ct-interactive/win-feast)' CT Interactive 5x3 cascade videoslot
* '[100 Burning Brilliants](https://www.slotsmate.com/software/ct-interactive/100-burning-brilliants)' CT Interactive 5x4 cascade videoslot
* '[Cave of Clovers](https://www.slotsmate.com/software/ct-interactive/cave-of-clovers)' CT Interactive 5x4 videoslot
* '[Hyper Cuber](https://www.livebet2.com/casino/slots/ct-interactive/hyper-cuber)' CT Interactive 5x3 cluster cascade videoslot
* '[Ice Fruits 6 reels](https://agtsoftware.com/games/agt/6megaice)' AGT 6x3 videoslot
* '[Tibetan Song](https://www.livebet2.com/casino/slots/ct-interactive/tibetan-song)' CT Interactive 5x3 videoslot
* '[Black Pharaoh](https://www.livebet2.com/casino/slots/ct-interactive/black-pharaoh)' CT Interactive 5x3 videoslot
* '[Christmas Storm](https://www.livebet2.com/casino/slots/ct-interactive/christmas-storm)' CT Interactive 5x3 cascade videoslot
* '[Beetle Star](https://www.livebet2.com/casino/slots/ct-interactive/beetle-star)' CT Interactive 5x3 videoslot
* '[Amazons Spear](https://www.livebet2.com/casino/slots/ct-interactive/amazons-spear)' CT Interactive 5x3 videoslot
* '[50 Treasures](https://www.livebet2.com/casino/slots/ct-interactive/50-treasures)' CT Interactive 5x4 videoslot
* '[20 Fruitata Wins](https://www.livebet2.com/casino/slots/ct-interactive/20-fruitata-wins)' CT Interactive 5x3 videoslot
* '[20 Star Party](https://www.livebet2.com/casino/slots/ct-interactive/20-star-party)' CT Interactive 5x3 videoslot
* '[30 Fruitata Wins](https://www.livebet2.com/casino/slots/ct-interactive/30-fruitata-wins)' CT Interactive 5x3 cascade videoslot
* '[40 Hell's Cherries](https://www.livebet2.com/casino/slots/ct-interactive/40-hell-s-cherries)' CT Interactive 5x4 videoslot
* '[40 Dice Treasures](https://www.livebet2.com/casino/slots/ct-interactive/40-dice-treasures)' CT Interactive 5x4 videoslot
* '[40 Shining Coins](https://www.livebet2.com/casino/slots/ct-interactive/40-shining-coins)' CT Interactive 5x4 videoslot
* '[40 Shining jewels](https://www.livebet2.com/casino/slots/ct-interactive/40-shining-jewels)' CT Interactive 5x4 videoslot
* '[Celestial Ruler](https://www.livebet2.com/casino/slots/ct-interactive/celestial-ruler)' CT Interactive 5x3 videoslot
* '[Banana Party](https://www.livebet2.com/casino/slots/ct-interactive/banana-party)' CT Interactive 5x3 videoslot
* '[20 Dice Party](https://www.livebet2.com/casino/slots/ct-interactive/20-dice-party)' CT Interactive 5x3 videoslot
* '[Easter Bonanza](https://www.livebet2.com/casino/slots/ct-interactive/easter-bonanza)' CT Interactive 5x4 videoslot

*Games with most interesting algorithms released on server*:

* 'Aztec Gold' Megajack 5x3 videoslot has unique 'Aztec Pyramid' bonus game
* '[Book of Ra Deluxe](https://www.slotsmate.com/software/novomatic/book-of-ra-deluxe)' Novomatic 5x3 videoslot with special expanding symbol on free games
* '[Gonzo's Quest](https://www.slotsmate.com/software/netent/gonzos-quest)' NetEnt 5x3 cascade videoslot
* '[Hyper Cuber](https://www.livebet2.com/casino/slots/ct-interactive/hyper-cuber)' CT Interactive 5x3 cluster cascade videoslot with symbols-multipliers on free games
* '[Fruit Shop](https://www.slotsmate.com/software/netent/fruit-shop)' NetEnt 5x3 videoslot with free spins on every win
* '[Sun City](https://agtsoftware.com/games/agt/suncity)' AGT 5x3 videoslot with free games continous by the luck
* '[Egypt](https://agtsoftware.com/games/agt/egypt)' AGT 5x3 videoslot with minislot for wilds multiplier
* 'Fire Joker' Play'n GO 5x3 videoslot with jackpot on lined pays and big symbols on free games
* '[Secret Elixir](https://www.slotsmate.com/software/novomatic/secret-elixir)' Novomatic 5x3 videoslot with multipliers on 5th reel
* '[Caribbean Adventure](https://www.slotsmate.com/software/ct-interactive/caribbean-adventure)' CT Interactive 5x3 videoslot, all symbols pays as scatters on freegames
* '[Vikings Fun](https://www.slotsmate.com/software/ct-interactive/vikings-fun)' CT Interactive 5x3 videoslot, some symbols become wilds on free games
* '[Ultra Sevens](https://www.slotsmate.com/software/novomatic/ultra-sevens)' Novomatic 5x4 videoslot with 3 jackpots

## How to build from sources

*Note: you can download the compiled binaries for Windows at [release](https://github.com/slotopol/server/releases/latest) section, or build docker image by [dockerfile](https://github.com/slotopol/server/blob/main/Dockerfile), or use compiled image from [docker hub](https://hub.docker.com/r/schwarzlichtbezirk/slotopol): `docker pull schwarzlichtbezirk/slotopol` and start image [as it described](docs/docker-config.md).*

1. Install [Golang](https://go.dev/dl/) of last version and GCC toolchain *(tip: for Windows it can be MinGW-w64 distribution from [WinLibs](https://winlibs.com/))*.
2. Clone project and download dependencies.
3. Build project with script at `task` directory.

Project can be [built](.github/workflows/go.yml) for Windows/Linux/MacOS.

For Windows command prompt:

```cmd
git clone https://github.com/slotopol/server.git
cd server
go mod download && go mod verify
task\build-win-x64.cmd
```

or for Linux shell or git bash:

```sh
git clone https://github.com/slotopol/server.git
cd server
go mod download && go mod verify
sudo chmod +x ./task/*.sh
./task/build-linux-x64.sh
```

Then web-service can be started:

```cmd
slot_win_x64 -v web
```

The [list of all](docs/list-all.md) provided games can be obtained by command:

```cmd
slot_win_x64 list
```

To find out the list of available RTPs can be with command like this

```cmd
slot_win_x64 list -i megajack --rtp
```

See `slot_win_x64 list -h` with full list of available command line parameters for list-command with filters.

## How to test

To calculate nearest precise RTP to given value for any game on embedded reels, you can use the command like

```cmd
slot_win_x64 scan -g=ctinteractive/luckydollar -r=95.0
```

Some games algorithms contains Lua-scripts with mathematical RTP calculation without full reels brute force, and returns result on a fly.

You can provide your own reels sets for any game at external yaml-file with same data structure as it in the sources by command

```cmd
slot_win_x64 -f=/some/path/reeldev.yaml web
```

To test gameplay workflow, build [bot](https://github.com/slotopol/bot) as it described, and run some scripts at `script` folder of project. See [readme](https://github.com/slotopol/bot/blob/main/README.md) for details.

## Architecture and logic

**Database.** Service instance oriented on monopoly usage of it's database. It reads necessary database tables on start and avoids any `select` requests at all. Then it stores to database only changes and new data (`update` & `insert`). Those queries are buffered across API endpoints calls to increase performance with database conversations.

It can be used embedded *sqlite* database engine, or *MySQL*, or *PostgreSQL* databases, its configured at `slot-app.yaml` settings file, and by default sqlite is used. Embedded sqlite engine useful for instance started on portable storage, such as flash drive or external SSD, and can serve small sets of players, 50-500 players at the same time. For big number of players it can be used dedicated server with MySQL or PostgreSQL on fast hosted disk.

**Clubs.** There is can be served several clubs. Each club have its own undepended bank, jackpot fund with rate to this fund from spins, and deposit. Bank of club is current balance of club to which arrives coins from users spins, and from which they gets a wins. There is exist linkage of users wins to bank: if bank have not enough coins to pay the win during users spins, this win combination will be skipped. Deposit of club does not used in games, it can be useful to transfer the coins from bank to fix the yield.

**Users accounts.** Accounts have registrations data only. Each account can be associated with several clubs. Each user can have properties for each club with individual balance to gamble, individual access rights, and individual master RTP to choose reels at games.

Each user can play several games at the same time. Each started game have game ID related to user ID and club ID. Any game actions ties to game ID.

## Mathematics of Slots

Built-in reels scanner helps to get parsheet with math description. There is two key parameters for reels: expectation value and standard deviation. Expectation value presented as RTP (Return To Player) value in percentages, and shows payout for unlimited long series of spins. Standard deviation helps to evaluate RTP spread for limited series, point of convergence, bankroll for user for any case, bankroll for house.

Let's examine the scan output values ​​using an example of `Gonzo's Quest` slot.

```txt
$ slot_debug.exe scan -g=netent/gonzosquest -r=95 --full
selected 20 lines
completed 100% (50722560), time spent 7.2566161s

reels lengths [34, 37, 35, 36, 32], total reshuffles 50722560
symbols: µ = 90.41822%, sigma(sym) = 5.72795
free: HRfg = 1/564.49, q = 0.017715, sq = 1/(1-q) = 1.018035
RTP = 90.418(sym) + 0.017715*276.15(fg) = 95.310212%
sigma = 6.17553, VI[95%] = 12.1038 (Medium-High)
CI[95%] = 66610, bankroll[CI] = 6247.72

RTP spread for spins number with confidence 95%:
    1000: 57.03% ... 133.59%
   10000: 83.21% ... 107.41%
   66610: 90.62% ... 100.00%
  100000: 91.48% ... 99.14%
 1000000: 94.10% ... 96.52%
10000000: 94.93% ... 95.69%

cascade metrics:
N[2] = 17002368, Ec2 = Kf2 = 1/2.9833
N[3] = 4022784, Ec3 = 1/12.609, Kf3 = 1/4.2265
N[4] = 974592, Ec4 = 1/52.045, Kf4 = 1/4.1277
N[5] = 284544, Ec5 = 1/178.26, Kf5 = 1/3.4251
Mcascade = 1.8768, ACL = 1.3153, Kfading = 1/3.9376, Ncascmax = 8

symbols contribution to payouts:
sym rate%  rtp% |     1     2     3     4     5
 1:     0     0 |     0     0     0     0     0
 2:     0     0 |     0     0     0     0     0
 3: 26.28 25.04 |     0     0  9.17 10.18  6.92
 4: 21.18 20.19 |     0     0  6.11  8.98  6.09
 5: 20.63 19.67 |     0     0  6.73  5.71  8.20
 6: 16.18 15.42 |     0     0  6.57  3.35  6.25
 7:  7.63  7.28 |     0     0  4.06  1.65  1.92
 8:  4.95  4.72 |     0     0  2.74  1.02  1.19
 9:  3.14  2.99 |     0     0  1.82  0.61  0.71

cascades contribution to payouts:
cfn rate%  rtp%
 1: 53.28 50.78
 2: 28.05 26.74
 3: 12.97 12.36
 4:  4.62  4.41
 5:  0.89  0.85
 6:  0.16  0.15
 7:  0.03  0.02
 8:     0     0
```

Here output means:

* `µ` is expectation value on pays without any special cases, calculated as $S/N$, where $S$ - sum of all pays, $N$ - total number of reshuffles. This value is used to produce final RTP later.

* `sigma(sym)` is standard deviation by plain pays, calculated as $Q/N - µ^2$, where $Q$ - sum of squares on all pays by every spin. This value shows standard deviation on a "clean" reels, it is not final value.

* $q = C_{fs}/N$, where $C_{fs}$ is sum of all wined free spins.

* $sq = \frac{1}{1-q}$ sum of an infinite decreasing geometric progression, multiplier to get RTP on recursive free spins.

* `HRfg` is free games hit rate, shows mathematical expectation of hit that starts series of free spins. Means how many spins to wait before free games hit.

* `RTP` and `sigma` - final key parameters of reels.

* `VI[95%]` - volatility on one spin with confidence 95%, expression $\frac{VI}{\sqrt{N}}$ helps to get the spread for series of $N$ spins.

* `CI[95%]` - index of convergence, the point at which variance does not cover the loss in expected value. Player will never been in profit after this point with confidence 95%. After this point house gets clean yield.

* `bankroll[CI]` - bankroll for player to get point of convergence. There is no mathematical reason for him to keep balance greater.

* `RTP spread` is the table with RTP intervals for different $N$ values. High volatility increases spread, and moves far away point of convergence.

* `N[2]`, `N[3]` ... - number of cascade falls #2, #3, etc in scanning pool.

* `Ec2`, `Ec3` ... - expectation of cascade fall #2, #3, etc. Shows how many spins to wait to get cascade fall with this number.

* `Kf2`, `Kf3` ... - expectation of "next" cascade fall. Fading coefficient for each cascade fall.

* `Mcascade` - key parameter for cascade slots, $S_{Σ}/S_1$, where $S_{Σ}$ - sum of pays by all cascades, $S_1$ - pays by 1st cascade fall. It shows how many cascades pays. A high value indicates that the bulk of the payouts comes from cascades, while linear payments are insignificant.

* `ACL` - Average Cascade Length.

* `Kfading` - average coefficient of fading.

* `Ncascmax` - maximum number of cascade falls by one spin on those reels. Including last fall with no wins.

* `symbols contribution` - shows the average contribution of each symbol to the payouts. `rate` column is share of payout, `rtp` column is share of RTP. At right side shares of symbols to payout by combinations lengths. This table shows how reels are balanced by payout.

* `cascades contribution` - shows the average contribution of each cascade fall to the payout.

## How to use HTTP API

Any API endpoints can receive data in JSON, XML, YAML, or TOML format, depended by `Content-Type` header. If `Content-Type` header not given, JSON will be used to decode as default. `Accept` header if it given, defines response data format. If it absent, same format as at request will be used.

In most cases used `POST`-method of HTTP.

If any response have HTTP status >= 400, body in this case contains error object with `what` field with message and unique source point error `code`.

### Without authorization

First of all you can test replies existence and service is running:

```sh
curl -i localhost:8080/ping
```

Any riplies have `Server` header with content like `slotopol/v0.10.0 (windows; amd64)`. By prefix `slotopol/` you can detect that service is our.

Then you can get a list of games supported by server. This call can be without authorization.

```sh
curl -X GET localhost:8080/game/algs
```

Response has array with available algorithms descriptions. Each structure has a list of games aliases, that shares one algorithm. Field `rtp` has the list of reels with predefined RTP. There is example of structure with info:

```json
,{"aliases":[{"prov":"NetEnt","name":"Trolls","year":2009},{"prov":"NetEnt","name":"Excalibur","year":2013},{"prov":"NetEnt","name":"Pandora's Box","year":2009},{"prov":"NetEnt","name":"Wild Witches","year":2010}],"gt":1,"gp":4628497,"sx":5,"sy":3,"sn":14,"ln":20,"rtp":[87.788791,89.230191,91.925079,93.061471,93.903358,95.183523,96.6485,98.193276,101.929305,110.298257]},
```

To get filtered list of games can be used call like

```sh
curl -X GET localhost:8080/game/list?inc=megajack+ct
```

Where `inc` contains space separated list of filters like in `list` command line parameters, see `slot_win_x64 list -h` for details.

`/servinfo` and `/memusage`, `/signis`, `/sendcode`, `/activate`, `/signup` and `/signin` endpoints also does not expects authorization.

### Authorization

There is supported basic authorization and bearer authorization (with JWT-tokens). Authorization data can be provided by 4 ways: in header `Authorization`, at query parameters, at cookies, and at post form.

**Basic** expects credentials pair `email:password` encoded in unpadded base64 encoding for URL (see RFC 4648).

**Bearer** works with two HS256 JWT tokens - access token and refresh token. Access token should be provided in all cases except `refresh` call. When access-token expires, it should be replaced to refresh-token for refresh-call.

In `/signin` call password can be given by two ways:

1) Explicitly at field `secret` as is.
2) By HMAC SHA256 hash and temporary public key (without send opened secret).

In second case it should be string in field `sigtime` with current time formatted in RFC3339 (can be with nanoseconds). And at field `hs256` it should be hexadecimal HMAC formed with algorithm SHA256 with this current time as a key, and password, i.e. sha256.hmac(sigtime, password). Allowed timeout for public key is 2m 30s.

* Sign-in, and use token from response with any followed calls.

```sh
curl -H "Content-Type: application/json" -d '{"email":"player@example.org","secret":"iVI05M"}' -X POST localhost:8080/signin
```

You can use token `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzbG90b3BvbCIsImV4cCI6NDg2NzQ0NzYxNywibmJmIjoxNzA2NjQ3NjE3LCJ1aWQiOjN9.6g2Hig9ErG8IbvzkPppry5F8HJsMunZPwuQzmetGh4c` for test purpose, it given for user with UID=3 on 100 years. Replace `{{token}}` at samples below to this value.

* When your access token expires (you can get response with 401 status code), use refresh-call with refresh-token to get new tokens pair.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -X GET localhost:8080/refresh
```

### Create and play the game

* Create new game. GID received at response will be used at all calls for access to this game instance. Also you will get initial game state, and user balance at this club.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"cid":1,"uid":3,"alias":"Novomatic/Joker Dolphin"}' -X POST localhost:8080/game/new
```

Endpoint receives `alias` identifier to game that represents as concatenation of provider name and game name with slash. For example, `NetEnt/Tiki Wonders`. Whole list of all supported games can be obtained by [list](docs/list-all.md) command. Identifier turns to lowercase without spaces.

* Change number of selected bet lines.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"gid":1,"sel":5}' -X POST localhost:8080/slot/sel/set
```

* Make a spin. Spin returns `sid` - spin ID, by this ID it can be found at the log; `grid` with new symbols after spin; `wins` with list of win on each line if it was; `fs` - free spins remained; `gain` - total gain after spin, that can be gambled on double up; `wallet` - user balance after spin with won coins.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"gid":1}' -X POST localhost:8080/slot/spin
```

At parameters can be also given new bet value and number of selected lines, if there is no free spins now. So, data at the query can be seen such as `{"gid":1,"bet":2,"sel":5}`. Its can be useful for conversations only by spin-queries.

* Double-up. If presents `gain` after spin, it can be multiplied by gamble. `mult` at argument is multiplier, and it will be `2` for red-black cards game. Returned `gain` will be multiplied on win, and zero on lose. `wallet` represents new balance of user.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"gid":1,"mult":2}' -X POST localhost:8080/slot/doubleup
```

* Collect the gain. After win on spin, or after double-up gain can be collected. In most cases it will be collected automatically on new spin.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"gid":1}' -X POST localhost:8080/slot/collect
```

* Get information about opened game. Recivies GID. Response has game name, game state, last spin ID, user ID, club ID, and user balance at this club.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"gid":1}' -X POST localhost:8080/game/info
```

### Work with user account

* Check up user account existence. It can be done by email or user identifier (`uid` parameter). Call returns true `uid` and `email` if account is found, or zero user identifier if account does not registered.

```sh
curl -X GET localhost:8080/signis?email=rob@example.org
```

* Register new user. E-mail and secret key (password) are expected, name can be omitted. Receives user ID on success.

```sh
curl -H "Content-Type: application/json" -d '{"email":"rob@example.org","secret":"LtpkAr","name":"rob"}' -X POST localhost:8080/signup
```

After registration new user account expects account activation by code sent to user email. Activation can be done by `/activate` endpoint call. If registration of new user was done with admin token, this new user account does not expects activation.

* Activate new user account. It can be done by code sent to user account email. Activation should be done in 15 minutes timeout after registration. If timeout expired activation can be done with new code, sent to email by `/sendcode` endpoint call.

```sh
curl -X GET localhost:8080/activate?uid=3&code=048814
```

Instead `uid` parameter with user identifier can be used user `email`. If activation endpoint was called with admin token, activation code have no matter.

* Send new activation code to user email.

```sh
curl -X GET localhost:8080/sendcode?uid=3
```

Instead `uid` parameter with user identifier can be used user `email`.

* Rename user.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"uid":3,"name":"erigone"}' -X POST localhost:8080/user/rename
```

* Change secret key.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"uid":3,"oldsecret":"iVI05M","newsecret":"pGjKsd"}' -X POST localhost:8080/user/secret
```

* Delete user. Delete-call removes account from database, move all remained user's coins to deposit, and removes all users games from database.

```sh
curl -H "Content-Type: application/json" -H "Authorization: Bearer {{token}}" -d '{"uid":3,"secret":"iVI05M"}' -X POST localhost:8080/user/delete
```

---
(c) schwarzlichtbezirk, 2024-2026.
