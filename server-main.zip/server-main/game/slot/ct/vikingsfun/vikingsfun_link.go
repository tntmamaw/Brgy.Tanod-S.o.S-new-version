//go:build !prod || full || ct

package vikingsfun

import (
	_ "embed"

	"github.com/slotopol/server/game"
)

//go:embed vikingsfun_data.yaml
var data []byte

var Info = game.AlgInfo{
	Aliases: []game.GameAlias{
		{Prov: "CT Interactive", Name: "Vikings Fun", LNum: 25, Date: game.Date(2020, 10, 26)}, // see: https://www.slotsmate.com/software/ct-interactive/vikings-fun
	},
	AlgDescr: game.AlgDescr{
		GT: game.GTslot,
		GP: game.GPlpay |
			game.GPfgseq |
			game.GPscat |
			game.GPwild |
			game.GPwturn,
		SX: 5,
		SY: 3,
		SN: sn,
		LN: len(BetLines),
		BN: 0,
	},
	Update: func(ai *game.AlgInfo) { ai.RTP = game.MakeRtpList(ReelsMap) },
}

func init() {
	Info.SetupFactory(func(sel int) game.Gamble { return NewGame(sel) }, CalcStat)
	game.DataRouter["ctinteractive/vikingsfun/rmap"] = &ReelsMap
	game.LoadMap = append(game.LoadMap, data)
}
