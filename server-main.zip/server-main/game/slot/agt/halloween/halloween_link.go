//go:build !prod || full || agt

package halloween

import (
	_ "embed"

	"github.com/slotopol/server/game"
)

//go:embed halloween_data.yaml
var data []byte

var Info = game.AlgInfo{
	Aliases: []game.GameAlias{
		{Prov: "AGT", Name: "Halloween", LNum: 10}, // see: https://agtsoftware.com/games/agt/halloween
	},
	AlgDescr: game.AlgDescr{
		GT: game.GTslot,
		GP: game.GPfgno,
		SX: 3,
		SY: 3,
		SN: sn,
		LN: len(BetLines),
		BN: 0,
	},
	Update: func(ai *game.AlgInfo) { ai.RTP = game.MakeRtpList(ReelsMap) },
}

func init() {
	Info.SetupFactory(func(sel int) game.Gamble { return NewGame(sel) }, CalcStat)
	game.DataRouter["agt/halloween/rmap"] = &ReelsMap
	game.LoadMap = append(game.LoadMap, data)
}
