//go:build !prod || full || agt

package cherryhot

import (
	_ "embed"

	"github.com/slotopol/server/game"
)

//go:embed cherryhot_data.yaml
var data []byte

var Info = game.AlgInfo{
	Aliases: []game.GameAlias{
		{Prov: "AGT", Name: "Cherry Hot", LNum: 5}, // see: https://agtsoftware.com/games/agt/cherryhot
	},
	AlgDescr: game.AlgDescr{
		GT: game.GTslot,
		GP: game.GPlpay |
			game.GPlsel |
			game.GPfgno |
			game.GPscat,
		SX: 5,
		SY: 3,
		SN: sn,
		LN: len(BetLines),
		BN: 0,
	},
	Update: func(ai *game.AlgInfo) { ai.RTP = game.MakeRtpList(ReelsMap) },
}

func init() {
	Info.SetupFactory(func(sel int) game.Gamble { return NewGame(sel) }, CalcStat)
	game.DataRouter["agt/cherryhot/rmap"] = &ReelsMap
	game.LoadMap = append(game.LoadMap, data)
}
