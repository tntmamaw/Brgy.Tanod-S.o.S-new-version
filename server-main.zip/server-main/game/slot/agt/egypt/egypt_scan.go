package egypt

import (
	"context"
	"fmt"
	"io"

	"github.com/slotopol/server/game/slot"
)

// Minislot expectation calculation:
// total combinations: 3*3*3 = 27
//
//	x1 = 27-3=24
//	x3 = 1
//	x6 = 1
//	x9 = 1
//
// Em = (24*1 + 1*3 + 1*6 + 1*9)/27 = 42/27 = 1.5555555556
const Em = 42. / 27.

func CalcStat(ctx context.Context, sp *slot.ScanPar) (float64, float64) {
	var reels, _ = ReelsMap.FindClosest(sp.MRTP)
	var g = NewGame(sp.Sel)
	var s = slot.NewStatGeneric(sn, 5)

	var calc = func(w io.Writer) (float64, float64) {
		var N, S, Q = s.NSQ(g.Cost())
		var µ = S / N
		var rtp = Em * µ
		var D = Em * Em * (Q/N - µ*µ)
		if sp.IsMain() {
			fmt.Fprintf(w, "symbols: µ = %.8g%%\n", µ*100)
			fmt.Fprintf(w, "RTP = %.5g(Em) * %.5g(sym) = %.8g%%\n", Em, µ*100, rtp*100)
		}
		slot.Print_all(w, sp, s, rtp, D)
		return rtp, D
	}

	return slot.ScanReelsCommon(ctx, sp, s, g, reels, calc)
}
