//go:build !prod || full || netent

package spellcast

import (
	_ "embed"

	"github.com/slotopol/server/game"
)

//go:embed spellcast_data.yaml
var data []byte

var Info = game.AlgInfo{
	Aliases: []game.GameAlias{
		{Prov: "NetEnt", Name: "Spellcast", LNum: 20, Date: game.Year(2006)},
		{Prov: "NetEnt", Name: "Secret Of Horus", LNum: 20, Date: game.Year(2013)},
	},
	AlgDescr: game.AlgDescr{
		GT: game.GTslot,
		GP: game.GPlpay |
			game.GPlsel |
			game.GPfgseq |
			game.GPfgmult |
			game.GPscat |
			game.GPwild |
			game.GPwmult,
		SX: 5,
		SY: 3,
		SN: sn,
		LN: len(BetLines),
		BN: 0,
	},
	Update: func(ai *game.AlgInfo) { ai.RTP = game.MakeRtpList(ReelsMap) },
}

func init() {
	Info.SetupFactory(func(sel int) game.Gamble { return NewGame(sel) }, CalcStat)
	game.DataRouter["netent/spellcast/rmap"] = &ReelsMap
	game.LoadMap = append(game.LoadMap, data)
}
